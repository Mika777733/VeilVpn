package app.veil.vpn.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.vpn.data.Files
import app.veil.vpn.data.IconStyle

@Composable
fun Tile(icon: ImageVector, color: Color) {
    val ap = LocalAppearance.current
    val p = LocalPalette.current
    val c = if (ap.iconStyle == IconStyle.MONO) p.sub else color
    val filled = ap.iconStyle == IconStyle.FILLED
    val shape = if (ap.circleTiles) CircleShape else RoundedCornerShape(12.dp)
    Box(
        Modifier.size(40.dp).clip(shape)
            .background(if (filled) c else c.copy(alpha = 0.16f))
            .border(1.dp, if (filled) Color.Transparent else c.copy(alpha = 0.32f), shape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = if (filled) Color.White else c, modifier = Modifier.size(21.dp))
    }
}

@Composable
fun Section(title: String? = null, footer: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth()) {
        if (title != null) {
            Text(
                title.uppercase(), style = MaterialTheme.typography.labelMedium, color = p.sub,
                letterSpacing = 0.8.sp, modifier = Modifier.padding(start = 16.dp, bottom = 7.dp)
            )
        }
        Column(Modifier.fillMaxWidth().clip(shape).background(p.card).border(1.dp, p.line, shape), content = content)
        if (footer != null) {
            Text(
                footer, style = MaterialTheme.typography.bodySmall, color = p.sub,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 7.dp)
            )
        }
    }
}

@Composable
fun RowDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(LocalPalette.current.line))
}

@Composable
private fun RowShell(onClick: (() -> Unit)?, content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 60.dp)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) { content() }
}

@Composable
private fun Titles(title: String, subtitle: String?, modifier: Modifier, color: Color? = null, font: FontFamily? = null) {
    val p = LocalPalette.current
    Column(modifier) {
        Text(
            title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium,
            color = color ?: p.text, fontFamily = font, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = p.sub)
    }
}

@Composable
fun NavRow(icon: ImageVector, color: Color, title: String, subtitle: String? = null, value: String? = null, onClick: () -> Unit) {
    val p = LocalPalette.current
    RowShell(onClick) {
        Tile(icon, color)
        Titles(title, subtitle, Modifier.weight(1f))
        if (value != null) {
            Text(value, color = p.sub, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.sub)
    }
}

@Composable
fun ToggleRow(icon: ImageVector?, color: Color, title: String, subtitle: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    RowShell({ onChange(!checked) }) {
        if (icon != null) Tile(icon, color)
        Titles(title, subtitle, Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun CheckRow(title: String, subtitle: String? = null, selected: Boolean, font: FontFamily? = null, onClick: () -> Unit) {
    RowShell(onClick) {
        Titles(title, subtitle, Modifier.weight(1f), color = if (selected) Green else null, font = font)
        if (selected) Icon(Icons.Filled.Check, null, tint = Green)
    }
}

@Composable
fun PingText(value: Int?) {
    val (text, color) = when {
        value == null -> "…" to LocalPalette.current.sub
        value < 0 -> "тайм-аут" to Red
        value < 80 -> "$value мс" to Green
        value < 180 -> "$value мс" to Orange
        else -> "$value мс" to Red
    }
    Text(text, color = color, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun BrandIcon(size: Dp) {
    val ap = LocalAppearance.current
    val context = LocalContext.current
    val accent = Color(ap.accent)
    val shape = RoundedCornerShape(size * 0.28f)
    val bitmap = remember(ap.hasCustomIcon, ap.iconRev) { if (ap.hasCustomIcon) Files.loadIcon(context) else null }
    if (bitmap != null) {
        Image(bitmap.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.size(size).clip(shape))
    } else {
        Box(Modifier.size(size).clip(shape).background(accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Shield, null, tint = accent, modifier = Modifier.size(size * 0.55f))
        }
    }
}

/** Схема маршрута: устройство → серверы → интернет. */
@Composable
fun RouteCard(names: List<String>, active: Boolean) {
    val shape = RoundedCornerShape(18.dp)
    val mids = when {
        names.size >= 2 -> listOf(0.40f, 0.66f)
        names.size == 1 -> listOf(0.52f)
        else -> emptyList()
    }
    val xs = listOf(0.12f) + mids + listOf(0.88f)
    val nodeColor = if (active) Green else Color(0xFF8A96AA)
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(124.dp).clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF1D3352), Color(0xFF132239))))
            .border(2.dp, Color.White.copy(alpha = 0.1f), shape)
    ) {
        val w = maxWidth
        Canvas(Modifier.fillMaxSize()) {
            val y = size.height * 0.5f
            val path = Path().apply {
                moveTo(xs[0] * size.width, y)
                for (i in 1 until xs.size) {
                    val a = xs[i - 1] * size.width
                    val b = xs[i] * size.width
                    quadraticBezierTo((a + b) / 2, y - 36.dp.toPx(), b, y)
                }
            }
            drawPath(
                path, if (active) Green else Color.White.copy(alpha = 0.4f),
                style = Stroke(2.dp.toPx(), pathEffect = if (active) PathEffect.dashPathEffect(floatArrayOf(18f, 24f)) else null)
            )
            for (i in 1 until xs.size - 1) {
                val c = Offset(xs[i] * size.width, y)
                drawCircle(nodeColor.copy(alpha = 0.3f), 11.dp.toPx(), c)
                drawCircle(nodeColor, 6.dp.toPx(), c)
                drawCircle(Color.White, 6.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))
            }
        }
        Icon(Icons.Filled.Smartphone, null, tint = Color.White,
            modifier = Modifier.offset(x = w * xs[0] - 13.dp, y = 62.dp - 13.dp).size(26.dp))
        Icon(Icons.Filled.Language, null, tint = Color.White,
            modifier = Modifier.offset(x = w * xs.last() - 14.dp, y = 62.dp - 14.dp).size(28.dp))
        names.forEachIndexed { i, name ->
            Text(
                name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.offset(x = w * xs[i + 1] - 45.dp, y = 80.dp).width(90.dp)
            )
        }
    }
}

@Composable
fun ScreenTitle(title: String, onBack: (() -> Unit)? = null, actions: @Composable () -> Unit = {}) {
    val p = LocalPalette.current
    Column {
        if (onBack != null) {
            Row(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onBack).padding(vertical = 6.dp, horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(p.card), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = p.sub, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text("Назад", color = p.text, style = MaterialTheme.typography.bodyLarge)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold,
                color = p.text, modifier = Modifier.weight(1f))
            actions()
        }
    }
}
