package app.veil.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import app.veil.vpn.MainActivity
import app.veil.vpn.data.Files
import app.veil.vpn.data.SplitMode
import app.veil.vpn.data.Store
import app.veil.vpn.data.XrayConfig
import kotlinx.coroutines.flow.MutableStateFlow
import veilcore.Veilcore

enum class VpnState { OFF, CONNECTING, ON }

/**
 * Пакеты из TUN → tun2socks → SOCKS 127.0.0.1:10808 → Xray → VLESS-сервер.
 * Само приложение исключено из VPN, поэтому соединения Xray идут мимо туннеля и петли нет.
 */
class VeilVpnService : VpnService() {

    companion object {
        const val ACTION_START = "app.veil.vpn.START"
        const val ACTION_STOP = "app.veil.vpn.STOP"
        private const val CHANNEL = "veil_vpn"
        val state = MutableStateFlow(VpnState.OFF)
        val connectedAt = MutableStateFlow(0L)
        val lastError = MutableStateFlow<String?>(null)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        showNotification()
        Thread { startVpn() }.start()
        return START_STICKY
    }

    private fun startVpn() {
        state.value = VpnState.CONNECTING
        try {
            val store = Store(this)
            val s = store.tunnel
            val config = Files.config(this).readText()

            Veilcore.setAssetDir(filesDir.absolutePath)
            Veilcore.startXray(config)

            val b = Builder()
                .setSession("Veil")
                .setMtu(1500)
                .addAddress("10.10.14.1", 30)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(s.dns)
            if (s.ipv6) {
                b.addAddress("fd00:1:fd00:1::1", 126)
                b.addRoute("::", 0)
            }
            if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)

            // Раздельное туннелирование по приложениям
            when {
                s.appMode == SplitMode.INCLUDE && s.apps.isNotEmpty() ->
                    s.apps.forEach { runCatching { b.addAllowedApplication(it) } }
                s.appMode == SplitMode.EXCLUDE -> {
                    b.addDisallowedApplication(packageName)
                    s.apps.forEach { runCatching { b.addDisallowedApplication(it) } }
                }
                else -> b.addDisallowedApplication(packageName)
            }

            val tun = b.establish() ?: throw IllegalStateException("Нет разрешения на VPN")
            Veilcore.startTun(tun.detachFd().toLong(), XrayConfig.SOCKS_PORT.toLong(), 1500L)

            connectedAt.value = System.currentTimeMillis()
            state.value = VpnState.ON
            lastError.value = null
        } catch (e: Exception) {
            lastError.value = e.message ?: "Не удалось подключиться"
            stopVpn()
        }
    }

    private fun stopVpn() {
        runCatching { Veilcore.stop() }
        state.value = VpnState.OFF
        connectedAt.value = 0L
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() = stopVpn()

    override fun onDestroy() {
        runCatching { Veilcore.stop() }
        state.value = VpnState.OFF
        super.onDestroy()
    }

    private fun showNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VeilVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = builder
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Veil")
            .setContentText("VPN включён")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Отключить", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}
