package app.veil.vpn

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import app.veil.vpn.ui.AppViewModel
import app.veil.vpn.ui.VeilRoot
import app.veil.vpn.vpn.VeilVpnService
import app.veil.vpn.vpn.VpnState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startVpnService() else vm.error = "Без разрешения VPN подключиться нельзя"
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { VeilRoot(vm, onToggle = ::toggleVpn) }
    }

    private fun toggleVpn() {
        if (VeilVpnService.state.value != VpnState.OFF) {
            startService(Intent(this, VeilVpnService::class.java).setAction(VeilVpnService.ACTION_STOP))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        lifecycleScope.launch {
            if (!vm.prepareConfig()) return@launch
            val intent = VpnService.prepare(this@MainActivity)
            if (intent != null) vpnPermission.launch(intent) else startVpnService()
        }
    }

    private fun startVpnService() {
        ContextCompat.startForegroundService(
            this, Intent(this, VeilVpnService::class.java).setAction(VeilVpnService.ACTION_START)
        )
    }
}
