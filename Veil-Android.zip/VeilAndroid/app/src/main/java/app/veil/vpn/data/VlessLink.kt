package app.veil.vpn.data

import java.net.URLDecoder

/** Разбор ссылки vless://uuid@host:port?security=reality&sni=…&pbk=…#Имя */
class VlessLink private constructor(
    val uuid: String,
    val host: String,
    val port: Int,
    val params: Map<String, String>,   // ключи в нижнем регистре
    val name: String,
) {
    val security: String get() = (params["security"] ?: "none").lowercase()
    val network: String get() = (params["type"] ?: "tcp").lowercase()
    val isEncrypted: Boolean get() = security in setOf("reality", "tls", "xtls")
    val encryptionTitle: String
        get() = when (security) {
            "reality" -> "Reality · TLS 1.3"
            "tls", "xtls" -> "TLS 1.3"
            else -> "Без TLS"
        }

    fun toProfile(raw: String) = ServerProfile(
        name = name, link = raw.trim(), host = host, port = port, security = security
    )

    companion object {
        private val RE = Regex(
            "^vless://([^@\\s]+)@(\\[[^\\]]+\\]|[^:/?#\\s]+):(\\d{1,5})/?(?:\\?([^#\\s]*))?$",
            RegexOption.IGNORE_CASE
        )

        fun parse(raw: String): VlessLink? {
            val s = raw.trim()
            val hash = s.indexOf('#')
            val main = if (hash >= 0) s.substring(0, hash) else s
            val fragment = if (hash >= 0) decode(s.substring(hash + 1)) else ""
            val m = RE.matchEntire(main) ?: return null
            val port = m.groupValues[3].toIntOrNull()?.takeIf { it in 1..65535 } ?: return null
            val params = m.groupValues[4].split('&').filter { it.isNotEmpty() }.associate { kv ->
                val i = kv.indexOf('=')
                if (i < 0) kv.lowercase() to "" else kv.substring(0, i).lowercase() to decode(kv.substring(i + 1))
            }
            val host = m.groupValues[2].trim('[', ']')
            return VlessLink(decode(m.groupValues[1]), host, port, params, fragment.ifEmpty { host })
        }

        private fun decode(x: String): String =
            try { URLDecoder.decode(x.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { x }
    }
}
