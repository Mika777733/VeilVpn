package app.veil.vpn.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lens
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import app.veil.vpn.data.Files
import app.veil.vpn.data.IconStyle
import app.veil.vpn.data.SplitMode
import app.veil.vpn.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val DNS = listOf("Cloudflare" to "1.1.1.1", "Google" to "8.8.8.8", "Quad9" to "9.9.9.9", "AdGuard" to "94.140.14.14")

@Composable
fun SettingsScreen(vm: AppViewModel, open: (String) -> Unit) {
    val context = LocalContext.current
    var confirmReset by remember { mutableStateOf(false) }
    val t = vm.tunnel
    ScreenTitle("Настройки")
    Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Section {
            NavRow(Icons.Filled.Palette, Color(0xFF5B8CFF), "Оформление", value = vm.appearance.theme.title) { open("appearance") }
        }
        Section("Туннель", "Изменения применяются при следующем подключении.") {
            NavRow(Icons.Filled.Route, Color(0xFF22C3C3), "Многократный переход", value = if (t.multihop) "Всегда" else "Никогда") { open("multihop") }
            RowDivider()
            NavRow(Icons.Filled.CallSplit, Color(0xFFFF9F2E), "Раздельное туннелирование",
                value = if (t.appMode == SplitMode.ALL && t.domainMode == SplitMode.ALL) "Выкл." else "Вкл.") { open("split") }
            RowDivider()
            NavRow(Icons.Filled.Dns, Color(0xFFA970FF), "DNS", value = DNS.firstOrNull { it.second == t.dns }?.first ?: t.dns) { open("dns") }
            RowDivider()
            NavRow(Icons.Filled.Block, Red, "Kill Switch", subtitle = "Включается в системных настройках VPN") {
                context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
            }
        }
        Section("Трафик") {
            ToggleRow(Icons.Filled.Layers, Color(0xFF5B8CFF), "Мультиплексирование", "Не работает с XTLS-Vision", t.mux) { v -> vm.updateTunnel { it.copy(mux = v) } }
            RowDivider()
            ToggleRow(Icons.Filled.ContentCut, Color(0xFFFF6B8B), "Фрагментация TLS", "Помогает при блокировках по DPI", t.fragment) { v -> vm.updateTunnel { it.copy(fragment = v) } }
            RowDivider()
            ToggleRow(Icons.Filled.Public, Color(0xFF7C8CFF), "IPv6 через туннель", null, t.ipv6) { v -> vm.updateTunnel { it.copy(ipv6 = v) } }
            RowDivider()
            ToggleRow(Icons.Filled.Home, Green, "Локальная сеть напрямую", "Принтеры, NAS, роутер", t.bypassLan) { v -> vm.updateTunnel { it.copy(bypassLan = v) } }
        }
        Section("Отладка") {
            NavRow(Icons.Filled.Description, Color(0xFF5B8CFF), "Логи туннеля") { open("logs") }
        }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Red.copy(alpha = 0.1f))
                .border(1.dp, Red.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                .clickable { confirmReset = true }.padding(15.dp),
            contentAlignment = Alignment.Center
        ) { Text("Сбросить настройки", color = Red, fontWeight = FontWeight.SemiBold) }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Удалить все ключи и настройки?") },
            confirmButton = { TextButton({ confirmReset = false; vm.reset() }) { Text("Сбросить", color = Red) } },
            dismissButton = { TextButton({ confirmReset = false }) { Text("Отмена") } }
        )
    }
}

@Composable
fun SettingsRoute(route: String, vm: AppViewModel, open: (String) -> Unit, back: () -> Unit) {
    when (route) {
        "appearance" -> AppearanceScreen(vm, back)
        "multihop" -> MultihopScreen(vm, back)
        "split" -> SplitScreen(vm, back)
        "dns" -> DnsScreen(vm, back)
        "logs" -> LogsScreen(back)
    }
}

@Composable
private fun DnsScreen(vm: AppViewModel, back: () -> Unit) {
    var custom by remember { mutableStateOf(if (DNS.any { it.second == vm.tunnel.dns }) "" else vm.tunnel.dns) }
    ScreenTitle("DNS", back)
    Section {
        DNS.forEachIndexed { i, (name, ip) ->
            CheckRow(name, ip, vm.tunnel.dns == ip) { vm.updateTunnel { it.copy(dns = ip) } }
            if (i != DNS.lastIndex) RowDivider()
        }
    }
    Section("Свой DNS", "IP-адрес DNS-сервера.") {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(custom, { custom = it }, Modifier.weight(1f), placeholder = { Text("1.0.0.1") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            TextButton(onClick = { if (custom.isNotBlank()) vm.updateTunnel { it.copy(dns = custom.trim()) } }) { Text("OK") }
        }
    }
}

@Composable
private fun AppearanceScreen(vm: AppViewModel, back: () -> Unit) {
    val ap = vm.appearance
    val p = LocalPalette.current
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::installFont) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let(vm::setIcon) }
    val swatches = listOf(0xFF4A8CFF, 0xFF3CCF6A, 0xFFA970FF, 0xFFFF6B8B, 0xFFFF9F2E, 0xFF22C3C3, 0xFFF5C518, 0xFFE5484D)
    val fonts = listOf("system" to "Системный", "sans" to "Sans Serif", "serif" to "Serif", "mono" to "Monospace", "cursive" to "Рукописный")

    ScreenTitle("Оформление", back)
    Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Section("Тема") {
            ThemeMode.entries.forEachIndexed { i, m ->
                CheckRow(m.title, selected = ap.theme == m) { vm.updateAppearance { it.copy(theme = m) } }
                if (i != ThemeMode.entries.lastIndex) RowDivider()
            }
        }
        Section("Акцентный цвет") {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                swatches.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(3.dp, if (ap.accent == c) p.text else Color.Transparent, CircleShape)
                            .clickable { vm.updateAppearance { it.copy(accent = c) } }
                    )
                }
            }
        }
        Section("Шрифт", "Свой шрифт — файл TTF или OTF. Для русского текста в нём должна быть кириллица.") {
            fonts.forEach { (key, title) ->
                CheckRow(title, selected = ap.font == key, font = resolveFont(LocalContext.current, key)) {
                    vm.updateAppearance { it.copy(font = key) }
                }
                RowDivider()
            }
            vm.customFontName?.let { name ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        CheckRow("Свой: $name", selected = ap.font == "custom", font = resolveFont(LocalContext.current, "custom")) {
                            vm.updateAppearance { it.copy(font = "custom") }
                        }
                    }
                    IconButton(onClick = vm::removeFont) { Icon(Icons.Filled.Delete, "Удалить шрифт", tint = Red) }
                }
                RowDivider()
            }
            NavRow(Icons.Filled.FontDownload, Color(0xFFA970FF), "Загрузить свой шрифт") {
                fontPicker.launch(arrayOf("font/*", "application/x-font-ttf", "application/x-font-otf", "application/octet-stream"))
            }
        }
        Section("Иконки", "Своя картинка обрезается до квадрата и показывается внутри приложения.") {
            Row(
                Modifier.fillMaxWidth().clickable {
                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                BrandIcon(40.dp)
                Text("Своя иконка приложения", color = p.text, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.Image, null, tint = p.sub)
            }
            if (ap.hasCustomIcon) {
                RowDivider()
                TextButton(onClick = vm::removeIcon, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Убрать свою иконку", color = Red) }
            }
            RowDivider()
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconStyle.entries.forEach { s ->
                    val on = ap.iconStyle == s
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                            .background(if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else p.bg)
                            .clickable { vm.updateAppearance { it.copy(iconStyle = s) } }.padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(s.title, color = if (on) MaterialTheme.colorScheme.primary else p.sub, style = MaterialTheme.typography.labelLarge) }
                }
            }
            RowDivider()
            ToggleRow(Icons.Filled.Lens, Color(0xFF5B8CFF), "Круглые плитки", null, ap.circleTiles) { v -> vm.updateAppearance { it.copy(circleTiles = v) } }
        }
    }
}

@Composable
private fun MultihopScreen(vm: AppViewModel, back: () -> Unit) {
    val p = LocalPalette.current
    val t = vm.tunnel
    ScreenTitle("Многократный переход", back)
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        RouteCard(listOf("Вход", "Выход"), t.multihop)
        Text("Трафик сначала идёт на входной сервер, а в интернет выходит через другой. Так сложнее отследить, откуда пришёл запрос, но скорость ниже.",
            color = p.sub, style = MaterialTheme.typography.bodyLarge)
        Section("Режим") {
            CheckRow("Никогда", selected = !t.multihop) { vm.updateTunnel { it.copy(multihop = false) } }
            RowDivider()
            CheckRow("Всегда", selected = t.multihop) { vm.updateTunnel { it.copy(multihop = true) } }
        }
        if (t.multihop) {
            Section("Входной сервер", if (vm.servers.size < 2) "Добавьте хотя бы два ключа, чтобы построить цепочку."
                else "Выходной — сервер, выбранный на главном экране.") {
                vm.servers.forEachIndexed { i, s ->
                    CheckRow(s.name, "${s.host}:${s.port}", t.entryId == s.id) { vm.updateTunnel { it.copy(entryId = s.id) } }
                    if (i != vm.servers.lastIndex) RowDivider()
                }
            }
        }
    }
}

private data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap?)

@Composable
private fun SplitScreen(vm: AppViewModel, back: () -> Unit) {
    val p = LocalPalette.current
    val context = LocalContext.current
    val t = vm.tunnel
    var newDomain by remember { mutableStateOf("") }
    var appQuery by remember { mutableStateOf("") }
    val apps by produceState(initialValue = emptyList<AppInfo>()) {
        value = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .map { it.activityInfo.applicationInfo }
                .filter { it.packageName != context.packageName }
                .distinctBy { it.packageName }
                .map { info ->
                    AppInfo(info.loadLabel(pm).toString(), info.packageName,
                        runCatching { info.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull())
                }
                .sortedBy { it.label.lowercase() }
        }
    }

    ScreenTitle("Раздельное туннелирование", back)
    Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Section("Приложения") {
            CheckRow("Все приложения через VPN", selected = t.appMode == SplitMode.ALL) { vm.updateTunnel { it.copy(appMode = SplitMode.ALL) } }
            RowDivider()
            CheckRow("Только выбранные через VPN", "Остальные — напрямую", t.appMode == SplitMode.INCLUDE) { vm.updateTunnel { it.copy(appMode = SplitMode.INCLUDE) } }
            RowDivider()
            CheckRow("Выбранные — напрямую", "Остальные — через VPN", t.appMode == SplitMode.EXCLUDE) { vm.updateTunnel { it.copy(appMode = SplitMode.EXCLUDE) } }
        }
        if (t.appMode != SplitMode.ALL) {
            Section("Выбор приложений", if (apps.isEmpty()) "Загружаю список…" else null) {
                OutlinedTextField(appQuery, { appQuery = it }, Modifier.fillMaxWidth().padding(12.dp), placeholder = { Text("Поиск") }, singleLine = true)
                apps.filter { appQuery.isBlank() || it.label.contains(appQuery, ignoreCase = true) }.forEach { app ->
                    val checked = app.pkg in t.apps
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            vm.updateTunnel { it.copy(apps = if (checked) it.apps - app.pkg else it.apps + app.pkg) }
                        }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (app.icon != null) Image(app.icon, null, Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)))
                        else Tile(Icons.Filled.Apps, p.sub)
                        Text(app.label, color = p.text, modifier = Modifier.weight(1f))
                        Switch(checked, { v -> vm.updateTunnel { it.copy(apps = if (v) it.apps + app.pkg else it.apps - app.pkg) } },
                            colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White))
                    }
                }
            }
        }
        Section("Сайты") {
            CheckRow("Выкл.", selected = t.domainMode == SplitMode.ALL) { vm.updateTunnel { it.copy(domainMode = SplitMode.ALL) } }
            RowDivider()
            CheckRow("Только выбранные сайты через VPN", selected = t.domainMode == SplitMode.INCLUDE) { vm.updateTunnel { it.copy(domainMode = SplitMode.INCLUDE) } }
            RowDivider()
            CheckRow("Выбранные сайты — напрямую", selected = t.domainMode == SplitMode.EXCLUDE) { vm.updateTunnel { it.copy(domainMode = SplitMode.EXCLUDE) } }
        }
        if (t.domainMode != SplitMode.ALL) {
            Section("Список сайтов", "Правило для example.com действует и на поддомены.") {
                t.domains.forEach { d ->
                    Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(d, color = p.text, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.updateTunnel { it.copy(domains = it.domains - d) } }) {
                            Icon(Icons.Filled.Delete, "Удалить", tint = Red)
                        }
                    }
                    RowDivider()
                }
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newDomain, { newDomain = it }, Modifier.weight(1f), placeholder = { Text("example.com") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                    TextButton(onClick = {
                        val d = newDomain.trim().lowercase().substringAfter("://").substringBefore("/")
                        if ((d.contains('.') || d.contains(':')) && d !in t.domains) vm.updateTunnel { it.copy(domains = it.domains + d) }
                        newDomain = ""
                    }) { Text("Добавить") }
                }
            }
        }
    }
}

@Composable
private fun LogsScreen(back: () -> Unit) {
    val p = LocalPalette.current
    val context = LocalContext.current
    var revision by remember { mutableStateOf(0) }
    val text = remember(revision) { Files.log(context).takeIf { it.exists() }?.readText()?.takeLast(20_000).orEmpty() }
    ScreenTitle("Логи", back) {
        TextButton(onClick = { revision++ }) { Text("Обновить") }
        TextButton(onClick = { Files.log(context).writeText(""); revision++ }) { Text("Очистить") }
    }
    Section {
        Text(
            text.ifEmpty { "Записей нет. Подключитесь — здесь появятся сообщения Xray." },
            color = if (text.isEmpty()) p.sub else p.text, fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(16.dp)
        )
    }
}
