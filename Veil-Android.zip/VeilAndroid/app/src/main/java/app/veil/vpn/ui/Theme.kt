package app.veil.vpn.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Typeface
import app.veil.vpn.data.AppearanceSettings
import app.veil.vpn.data.Files
import app.veil.vpn.data.ThemeMode

data class Palette(val bg: Color, val card: Color, val line: Color, val sub: Color, val text: Color, val dark: Boolean)

val DarkPalette = Palette(Color(0xFF0E0E11), Color(0xFF1B1B1F), Color(0x14FFFFFF), Color(0xFF9B9BA5), Color(0xFFF3F3F6), true)
val LightPalette = Palette(Color(0xFFF2F2F7), Color.White, Color(0x14000000), Color(0xFF6C6C76), Color(0xFF111114), false)
val NavyPalette = Palette(Color(0xFF14233A), Color(0xFF1D3150), Color(0x17FFFFFF), Color(0xFFA9B6CB), Color(0xFFF3F3F6), true)
val AmoledPalette = Palette(Color.Black, Color(0xFF0E0E10), Color(0x14FFFFFF), Color(0xFF9B9BA5), Color(0xFFF3F3F6), true)

val Green = Color(0xFF3CCF6A)
val Orange = Color(0xFFF0A93A)
val Red = Color(0xFFFF5C61)

val LocalPalette = staticCompositionLocalOf { DarkPalette }
val LocalAppearance = staticCompositionLocalOf { AppearanceSettings() }

fun resolveFont(context: Context, key: String): FontFamily = when (key) {
    "sans" -> FontFamily.SansSerif
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    "custom" -> Files.loadFont(context)?.let { FontFamily(Typeface(it)) } ?: FontFamily.Default
    else -> FontFamily.Default
}

private fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f), headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f), bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f),
)

@Composable
fun VeilTheme(appearance: AppearanceSettings, fontRevision: Any?, content: @Composable () -> Unit) {
    val system = isSystemInDarkTheme()
    val palette = when (appearance.theme) {
        ThemeMode.SYSTEM -> if (system) DarkPalette else LightPalette
        ThemeMode.DARK -> DarkPalette
        ThemeMode.LIGHT -> LightPalette
        ThemeMode.NAVY -> NavyPalette
        ThemeMode.AMOLED -> AmoledPalette
    }
    val accent = Color(appearance.accent)
    val context = LocalContext.current
    val font = remember(appearance.font, fontRevision) { resolveFont(context, appearance.font) }
    val scheme = if (palette.dark) {
        darkColorScheme(primary = accent, background = palette.bg, surface = palette.card,
            onBackground = palette.text, onSurface = palette.text, surfaceVariant = palette.card)
    } else {
        lightColorScheme(primary = accent, background = palette.bg, surface = palette.card,
            onBackground = palette.text, onSurface = palette.text, surfaceVariant = palette.card)
    }
    CompositionLocalProvider(LocalPalette provides palette, LocalAppearance provides appearance) {
        MaterialTheme(colorScheme = scheme, typography = Typography().withFont(font), content = content)
    }
}
