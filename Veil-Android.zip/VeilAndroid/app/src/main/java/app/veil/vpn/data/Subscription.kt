package app.veil.vpn.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Ссылка-подписка (https://…/sub/…), которую выдают VPN-сервисы.
 * Сервер отвечает списком ключей — обычно в base64, по одному на строку.
 */
object Subscription {
    fun isUrl(s: String): Boolean {
        val t = s.trim()
        return t.startsWith("https://", ignoreCase = true) || t.startsWith("http://", ignoreCase = true)
    }

    suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        val c = URL(url.trim()).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.instanceFollowRedirects = true
        // Многие панели отдают список ключей только «знакомым» клиентам
        c.setRequestProperty("User-Agent", "v2rayNG/1.9.0")
        c.setRequestProperty("Accept", "*/*")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw IOException("сервер ответил кодом $code")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun decode(body: String): String {
        val t = body.trim()
        if (t.contains("://")) return t
        val clean = t.replace(Regex("\\s"), "")
        for (flags in listOf(Base64.DEFAULT, Base64.URL_SAFE)) {
            val decoded = runCatching { String(Base64.decode(clean, flags), Charsets.UTF_8) }.getOrNull()
            if (decoded != null && decoded.contains("://")) return decoded
        }
        return t
    }
}
