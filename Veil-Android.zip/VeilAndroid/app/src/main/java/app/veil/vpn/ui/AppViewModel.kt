package app.veil.vpn.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.veil.vpn.data.AppearanceSettings
import app.veil.vpn.data.Files
import app.veil.vpn.data.ServerProfile
import app.veil.vpn.data.Store
import app.veil.vpn.data.TunnelSettings
import app.veil.vpn.data.VlessLink
import app.veil.vpn.data.XrayConfig
import app.veil.vpn.vpn.Ping
import app.veil.vpn.vpn.VeilVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(private val app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var servers by mutableStateOf(store.servers); private set
    var selectedId by mutableStateOf(store.selectedId); private set
    var autoSelect by mutableStateOf(store.autoSelect); private set
    var tunnel by mutableStateOf(store.tunnel); private set
    var appearance by mutableStateOf(store.appearance); private set
    var customFontName by mutableStateOf(Files.fontName(app)); private set
    val pings = mutableStateMapOf<String, Int>()     // -1 = тайм-аут
    var isPinging by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)

    val vpnState = VeilVpnService.state
    val connectedAt = VeilVpnService.connectedAt
    val vpnError = VeilVpnService.lastError

    init {
        if (servers.isNotEmpty()) pingAll()
    }

    // --- ключи ---

    fun addKeys(text: String): Int {
        val added = parseKeys(text).filter { n -> servers.none { it.link == n.link } }
        if (added.isEmpty()) return 0
        servers = servers + added
        store.servers = servers
        if (selectedId == null) select(added.first().id)
        pingAll()
        return added.size
    }

    fun delete(s: ServerProfile) {
        servers = servers.filterNot { it.id == s.id }
        store.servers = servers
        if (selectedId == s.id) select(servers.firstOrNull()?.id)
        if (tunnel.entryId == s.id) updateTunnel { it.copy(entryId = null) }
    }

    fun select(id: String?) { selectedId = id; store.selectedId = id; setAuto(false) }
    fun setAuto(on: Boolean) { autoSelect = on; store.autoSelect = on }

    // --- выбор сервера и пинг ---

    private fun pingValue(s: ServerProfile): Int = pings[s.id]?.let { if (it < 0) 99_999 else it } ?: 9_000

    val currentServer: ServerProfile?
        get() = if (autoSelect) servers.minByOrNull(::pingValue)
        else servers.firstOrNull { it.id == selectedId } ?: servers.firstOrNull()

    val entryServer: ServerProfile?
        get() {
            if (!tunnel.multihop) return null
            val id = tunnel.entryId ?: return null
            if (id == currentServer?.id) return null
            return servers.firstOrNull { it.id == id }
        }

    fun pingAll() {
        if (isPinging || servers.isEmpty()) return
        viewModelScope.launch { pingAllNow() }
    }

    private suspend fun pingAllNow() {
        isPinging = true
        val results = coroutineScope {
            servers.map { s -> async { s.id to Ping.tcp(s.host, s.port) } }.awaitAll()
        }
        results.forEach { (id, v) -> pings[id] = v ?: -1 }
        isPinging = false
    }

    /** Собирает конфиг Xray перед подключением. */
    suspend fun prepareConfig(): Boolean {
        if (autoSelect && pings.isEmpty()) pingAllNow()
        val server = currentServer ?: run { error = "Добавьте ключ, чтобы подключиться"; return false }
        val exit = VlessLink.parse(server.link) ?: run { error = "Ключ повреждён — добавьте его заново"; return false }
        val entry = entryServer?.let { VlessLink.parse(it.link) }
        return withContext(Dispatchers.IO) {
            runCatching {
                val json = XrayConfig.build(exit, entry, tunnel, Files.log(app).absolutePath, Files.hasGeo(app))
                Files.config(app).writeText(json)
            }.onFailure { error = it.message }.isSuccess
        }
    }

    // --- настройки ---

    fun updateTunnel(f: (TunnelSettings) -> TunnelSettings) { tunnel = f(tunnel); store.tunnel = tunnel }
    fun updateAppearance(f: (AppearanceSettings) -> AppearanceSettings) { appearance = f(appearance); store.appearance = appearance }

    fun installFont(uri: Uri) {
        val name = app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }?.substringBeforeLast('.') ?: "Свой шрифт"
        if (Files.installFont(app, uri, name)) {
            customFontName = name
            updateAppearance { it.copy(font = "custom") }
        } else {
            error = "Не удалось загрузить шрифт. Нужен файл TTF или OTF до 5 МБ."
        }
    }

    fun removeFont() {
        Files.removeFont(app); customFontName = null
        if (appearance.font == "custom") updateAppearance { it.copy(font = "system") }
    }

    fun setIcon(uri: Uri) {
        if (Files.saveIcon(app, uri)) updateAppearance { it.copy(hasCustomIcon = true, iconRev = it.iconRev + 1) }
        else error = "Не удалось открыть картинку"
    }

    fun removeIcon() {
        Files.removeIcon(app)
        updateAppearance { it.copy(hasCustomIcon = false, iconRev = it.iconRev + 1) }
    }

    fun reset() {
        store.clear(); Files.removeFont(app); Files.removeIcon(app)
        Files.config(app).delete()
        servers = emptyList(); selectedId = null; autoSelect = false
        tunnel = TunnelSettings(); appearance = AppearanceSettings(); customFontName = null
        pings.clear()
    }

    companion object {
        fun parseKeys(text: String): List<ServerProfile> =
            text.lines().mapNotNull { line -> VlessLink.parse(line)?.toProfile(line) }
    }
}
