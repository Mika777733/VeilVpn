package app.veil.vpn.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.veil.vpn.data.VlessLink
import app.veil.vpn.vpn.VpnState
import kotlinx.coroutines.delay

@Composable
fun VeilRoot(vm: AppViewModel, onToggle: () -> Unit) {
    VeilTheme(vm.appearance, vm.customFontName) {
        val p = LocalPalette.current
        val vpnError by vm.vpnError.collectAsState()
        Box(Modifier.fillMaxSize().background(p.bg)) {
            if (vm.servers.isEmpty()) {
                OnboardingScreen(vm)
            } else {
                var tab by rememberSaveable { mutableStateOf(0) }
                val stack = remember { mutableStateListOf<String>() }
                BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
                val open: (String) -> Unit = { stack.add(it) }
                val back: () -> Unit = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

                Column(
                    Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp).padding(top = 8.dp, bottom = 130.dp)
                ) {
                    val route = stack.lastOrNull()
                    when {
                        route != null -> SettingsRoute(route, vm, open, back)
                        tab == 0 -> HomeScreen(vm, onToggle) { tab = 1 }
                        tab == 1 -> ServersScreen(vm)
                        else -> SettingsScreen(vm, open)
                    }
                }
                TabBar(tab, Modifier.align(Alignment.BottomCenter)) { tab = it; stack.clear() }
            }
        }
        val message = vm.error ?: vpnError
        if (message != null) {
            AlertDialog(
                onDismissRequest = { vm.error = null; vm.vpnError.value = null },
                confirmButton = { TextButton({ vm.error = null; vm.vpnError.value = null }) { Text("OK") } },
                title = { Text("Ошибка") },
                text = { Text(message) }
            )
        }
    }
}

@Composable
private fun TabBar(selected: Int, modifier: Modifier, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    val accent = MaterialTheme.colorScheme.primary
    val items = listOf(Icons.Filled.Hub to "Подключение", Icons.Filled.Storage to "Серверы", Icons.Filled.Settings to "Настройки")
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp).fillMaxWidth()
            .clip(CircleShape).background(p.card.copy(alpha = 0.96f)).border(1.dp, p.line, CircleShape).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val on = i == selected
            Column(
                Modifier.weight(1f).clip(CircleShape).background(if (on) accent.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, label, tint = if (on) accent else p.sub, modifier = Modifier.size(22.dp))
                Text(label, style = MaterialTheme.typography.labelSmall, color = if (on) accent else p.sub,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

// ---------- Первый запуск ----------

@Composable
private fun KeyHint(text: String) {
    val parsed = AppViewModel.parseKeys(text)
    if (text.isBlank()) return
    val first = parsed.firstOrNull()?.let { VlessLink.parse(it.link) }
    val more = if (parsed.size > 1) " и ещё ${parsed.size - 1}" else ""
    val (icon, color, msg) = when {
        first == null -> Triple(Icons.Filled.Error, Red, "Ключ не распознан. Проверьте, что он скопирован целиком и начинается с vless://")
        !first.isEncrypted -> Triple(Icons.Filled.Warning, Orange, "Ключ без TLS: трафик до сервера не зашифрован$more")
        else -> Triple(Icons.Filled.CheckCircle, Green, "Ключ распознан: ${first.name}, ${first.host}:${first.port}, ${first.encryptionTitle}$more")
    }
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
        Text(msg, color = color, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun OnboardingScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    val valid = AppViewModel.parseKeys(text).isNotEmpty()
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        BrandIcon(72.dp)
        Text("Добро пожаловать в Veil", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = p.text)
        Text(
            "Чтобы начать, вставьте VLESS-ключ от вашего VPN-сервиса. Он начинается с vless:// и обычно приходит от провайдера или бота в Telegram.",
            color = p.sub, style = MaterialTheme.typography.bodyLarge
        )
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                placeholder = { Text("vless://uuid@host:443?security=reality&sni=…#Мой VPN") },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, autoCorrectEnabled = false),
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp)
            )
            KeyHint(text)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { clipboard.getText()?.text?.let { text = it.trim() } },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.ContentPaste, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp)); Text("Вставить")
                }
                Button(onClick = { vm.addKeys(text) }, enabled = valid, modifier = Modifier.weight(1f)) { Text("Продолжить") }
            }
        }
        Text("Ключ хранится только на этом устройстве. Можно вставить несколько ключей — по одному на строку.",
            color = p.sub, style = MaterialTheme.typography.bodySmall)
    }
}

// ---------- Главный экран ----------

@Composable
fun HomeScreen(vm: AppViewModel, onToggle: () -> Unit, openServers: () -> Unit) {
    val p = LocalPalette.current
    val state by vm.vpnState.collectAsState()
    val since by vm.connectedAt.collectAsState()
    val on = state == VpnState.ON
    val busy = state == VpnState.CONNECTING
    val server = vm.currentServer
    val link = server?.let { VlessLink.parse(it.link) }
    val route = listOfNotNull(vm.entryServer?.name, server?.name)

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(on) { while (on) { now = System.currentTimeMillis(); delay(1000) } }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BrandIcon(34.dp)
            Text("Veil", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = p.text)
        }
        val statusColor = if (on) Green else if (busy) Orange else Red
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(statusColor))
            Spacer(Modifier.width(8.dp))
            Text(if (on) "Защищено" else if (busy) "Подключение…" else "Не защищено",
                color = statusColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
        RouteCard(route, on)
        Box(Modifier.fillMaxWidth().padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
            PowerButton(on, busy, onToggle)
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                .border(1.dp, p.line, RoundedCornerShape(18.dp)).clickable(onClick = openServers).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Filled.Language, null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(server?.name ?: "Нет сервера", color = p.text, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text((if (vm.autoSelect) "Автовыбор · " else "") + (link?.let { "VLESS · ${it.encryptionTitle}" } ?: ""),
                    color = p.sub, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            PingText(server?.let { vm.pings[it.id] })
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.sub)
        }
        val elapsed = if (on && since > 0) ((now - since) / 1000).coerceAtLeast(0) else -1
        val time = if (elapsed < 0) "—" else "%02d:%02d:%02d".format(elapsed / 3600, (elapsed / 60) % 60, elapsed % 60)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("Время", time, Modifier.weight(1f))
            Stat("Шифрование", link?.encryptionTitle ?: "—", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("Транспорт", link?.network?.uppercase() ?: "—", Modifier.weight(1f))
            Stat("Приложения", vm.tunnel.appMode.let { if (it.name == "ALL") "Все" else it.title }, Modifier.weight(1f))
        }
    }
}

@Composable
private fun Stat(title: String, value: String, modifier: Modifier) {
    val p = LocalPalette.current
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(p.card).border(1.dp, p.line, RoundedCornerShape(18.dp)).padding(14.dp)
    ) {
        Text(title, color = p.sub, style = MaterialTheme.typography.labelMedium)
        Text(value, color = p.text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun PowerButton(on: Boolean, busy: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(0.92f, 1.12f, infiniteRepeatable(tween(1200), RepeatMode.Restart), label = "s")
    val alpha by pulse.animateFloat(1f, 0f, infiniteRepeatable(tween(1200), RepeatMode.Restart), label = "a")
    Box(contentAlignment = Alignment.Center) {
        if (busy) Box(Modifier.size(214.dp).scale(scale).border(2.dp, Orange.copy(alpha = alpha), CircleShape))
        Box(
            Modifier.size(190.dp).clip(CircleShape)
                .background(if (on) Green.copy(alpha = 0.18f) else p.card)
                .border(2.dp, if (on) Green.copy(alpha = 0.5f) else p.line, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PowerSettingsNew, if (on) "Отключить" else "Подключить",
                tint = if (on) Green else if (busy) Orange else p.sub, modifier = Modifier.size(68.dp))
        }
    }
}

// ---------- Серверы ----------

@Composable
fun ServersScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    var showAdd by remember { mutableStateOf(false) }
    ScreenTitle("Серверы") {
        IconButton(onClick = { vm.pingAll() }, enabled = !vm.isPinging) {
            if (vm.isPinging) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            else Icon(Icons.Filled.Refresh, "Проверить пинг", tint = MaterialTheme.colorScheme.primary)
        }
        IconButton(onClick = { showAdd = true }) { Icon(Icons.Filled.Add, "Добавить ключ", tint = MaterialTheme.colorScheme.primary) }
    }
    Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Section(footer = "Подключаться к серверу с наименьшим пингом.") {
            Row(
                Modifier.fillMaxWidth().clickable { vm.setAuto(!vm.autoSelect) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Tile(Icons.Filled.Bolt, Color(0xFFF5B301))
                Column(Modifier.weight(1f)) {
                    Text("Авто", color = if (vm.autoSelect) Green else p.text, fontWeight = FontWeight.Medium)
                    if (vm.autoSelect) vm.currentServer?.let {
                        Text("Сейчас: ${it.name}", color = p.sub, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Section("Мои ключи", "Нажмите на звёздочку, чтобы сделать сервер входным для многократного перехода.") {
            vm.servers.forEachIndexed { i, s ->
                var menu by remember { mutableStateOf(false) }
                val selected = !vm.autoSelect && vm.currentServer?.id == s.id
                val link = VlessLink.parse(s.link)
                Row(
                    Modifier.fillMaxWidth().clickable { vm.select(s.id) }.padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Tile(Icons.Filled.Dns, MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f)) {
                        Text(s.name, color = if (selected) Green else p.text, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${s.host}:${s.port} · ${link?.encryptionTitle ?: s.security}", color = p.sub,
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    PingText(vm.pings[s.id])
                    val isEntry = vm.tunnel.multihop && vm.tunnel.entryId == s.id
                    IconButton(onClick = {
                        vm.updateTunnel { t -> if (isEntry) t.copy(entryId = null) else t.copy(entryId = s.id, multihop = true) }
                    }) {
                        Icon(if (isEntry) Icons.Filled.Star else Icons.Outlined.StarOutline, "Входной сервер",
                            tint = if (isEntry) Color(0xFFF5B301) else p.sub)
                    }
                    Box {
                        TextButton(onClick = { menu = true }) { Text("⋯", color = p.sub) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; vm.delete(s) })
                        }
                    }
                }
                if (i != vm.servers.lastIndex) RowDivider()
            }
        }
    }
    if (showAdd) AddKeyDialog(vm) { showAdd = false }
}

@Composable
private fun AddKeyDialog(vm: AppViewModel, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    val count = AppViewModel.parseKeys(text).size
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Добавить ключ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, placeholder = { Text("vless://…") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp)
                )
                TextButton(onClick = { clipboard.getText()?.text?.let { text = it } }) { Text("Вставить из буфера") }
                if (text.isNotBlank()) {
                    Text(if (count > 0) "Распознано ключей: $count" else "Ключи не распознаны",
                        color = if (count > 0) Green else Red, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.addKeys(text); onClose() }, enabled = count > 0) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}

