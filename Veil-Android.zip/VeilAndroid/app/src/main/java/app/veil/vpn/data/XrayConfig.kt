package app.veil.vpn.data

import org.json.JSONArray
import org.json.JSONObject

/** Конфиг Xray: SOCKS-вход на 127.0.0.1, VLESS-выход, правила маршрутизации. */
object XrayConfig {
    const val SOCKS_PORT = 10808

    private val PRIVATE = listOf(
        "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16",
        "127.0.0.0/8", "fc00::/7", "fe80::/10"
    )

    fun build(exit: VlessLink, entry: VlessLink?, s: TunnelSettings, logPath: String, hasGeo: Boolean): String {
        val outbounds = JSONArray()
        outbounds.put(outbound(exit, "proxy", if (entry != null) "entry" else null, s))
        if (entry != null) outbounds.put(outbound(entry, "entry", null, s))
        outbounds.put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
        outbounds.put(JSONObject().put("tag", "block").put("protocol", "blackhole"))
        if (s.fragment) {
            outbounds.put(
                JSONObject().put("tag", "fragment").put("protocol", "freedom").put(
                    "settings", JSONObject().put(
                        "fragment", JSONObject().put("packets", "tlshello")
                            .put("length", "100-200").put("interval", "10-20")
                    )
                )
            )
        }

        val rules = JSONArray()
        if (s.bypassLan) rules.put(rule("ip", PRIVATE, "direct"))
        val domains = mutableListOf<String>()
        val ips = mutableListOf<String>()
        for (d in s.domains) {
            if (d.startsWith("geoip:")) {
                if (hasGeo) ips += d
            } else {
                domainRule(d, hasGeo)?.let { domains += it }
            }
        }
        when (s.domainMode) {
            SplitMode.ALL -> Unit
            SplitMode.EXCLUDE -> {
                if (domains.isNotEmpty()) rules.put(rule("domain", domains, "direct"))
                if (ips.isNotEmpty()) rules.put(rule("ip", ips, "direct"))
            }
            SplitMode.INCLUDE -> {
                if (domains.isNotEmpty()) rules.put(rule("domain", domains, "proxy"))
                if (ips.isNotEmpty()) rules.put(rule("ip", ips, "proxy"))
                rules.put(JSONObject().put("type", "field").put("network", "tcp,udp").put("outboundTag", "direct"))
            }
        }

        val inbound = JSONObject()
            .put("tag", "socks-in").put("listen", "127.0.0.1").put("port", SOCKS_PORT).put("protocol", "socks")
            .put("settings", JSONObject().put("udp", true).put("auth", "noauth"))
            .put(
                "sniffing", JSONObject().put("enabled", true)
                    .put("destOverride", JSONArray(listOf("http", "tls", "quic"))).put("routeOnly", true)
            )

        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning").put("error", logPath))
            .put("dns", JSONObject().put("servers", JSONArray(listOf(s.dns, "8.8.8.8"))))
            .put("inbounds", JSONArray().put(inbound))
            .put("outbounds", outbounds)
            .put("routing", JSONObject().put("domainStrategy", "AsIs").put("rules", rules))
            .toString(2)
    }

    private fun rule(field: String, values: List<String>, tag: String) =
        JSONObject().put("type", "field").put(field, JSONArray(values)).put("outboundTag", tag)

    fun domainRule(d: String, hasGeo: Boolean): String? {
        if (d.startsWith("geosite:")) return if (hasGeo) d else null
        if (listOf("domain:", "full:", "regexp:", "keyword:").any { d.startsWith(it) }) return d
        if (d.startsWith("*.")) return "domain:" + d.removePrefix("*.")
        return "domain:$d"
    }

    private fun outbound(l: VlessLink, tag: String, dialer: String?, s: TunnelSettings): JSONObject {
        val flow = l.params["flow"].orEmpty()
        val user = JSONObject().put("id", l.uuid).put("encryption", l.params["encryption"] ?: "none")
        if (flow.isNotEmpty()) user.put("flow", flow)

        val network = if (l.network == "splithttp") "xhttp" else l.network
        val stream = JSONObject().put("network", network)
            .put("security", if (l.security == "xtls") "tls" else l.security)
        when (l.security) {
            "reality" -> stream.put(
                "realitySettings", JSONObject()
                    .put("serverName", l.params["sni"].orEmpty())
                    .put("fingerprint", l.params["fp"] ?: "chrome")
                    .put("publicKey", l.params["pbk"].orEmpty())
                    .put("shortId", l.params["sid"].orEmpty())
                    .put("spiderX", l.params["spx"].orEmpty())
            )
            "tls", "xtls" -> {
                val tls = JSONObject().put("serverName", l.params["sni"] ?: l.host)
                    .put("fingerprint", l.params["fp"] ?: "chrome")
                l.params["alpn"]?.takeIf { it.isNotEmpty() }?.let { tls.put("alpn", JSONArray(it.split(","))) }
                if (l.params["allowinsecure"] == "1") tls.put("allowInsecure", true)
                stream.put("tlsSettings", tls)
            }
        }
        val path = l.params["path"] ?: "/"
        val hostHeader = l.params["host"].orEmpty()
        when (network) {
            "ws" -> stream.put("wsSettings", JSONObject().put("path", path).put("headers", JSONObject().put("Host", hostHeader)))
            "grpc" -> stream.put("grpcSettings", JSONObject().put("serviceName", l.params["servicename"].orEmpty()))
            "xhttp" -> stream.put("xhttpSettings", JSONObject().put("path", path).put("host", hostHeader).put("mode", l.params["mode"] ?: "auto"))
            "httpupgrade" -> stream.put("httpupgradeSettings", JSONObject().put("path", path).put("host", hostHeader))
        }
        // Цепочка серверов или фрагментация TLS для сервера, который подключается напрямую
        when {
            dialer != null -> stream.put("sockopt", JSONObject().put("dialerProxy", dialer))
            s.fragment -> stream.put("sockopt", JSONObject().put("dialerProxy", "fragment"))
        }

        val vnext = JSONObject().put("address", l.host).put("port", l.port).put("users", JSONArray().put(user))
        val ob = JSONObject().put("tag", tag).put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
            .put("streamSettings", stream)
        if (s.mux && flow.isEmpty()) ob.put("mux", JSONObject().put("enabled", true).put("concurrency", 8))
        return ob
    }
}
