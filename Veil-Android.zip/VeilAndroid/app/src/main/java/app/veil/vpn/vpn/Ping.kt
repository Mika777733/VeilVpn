package app.veil.vpn.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/** Пинг как время TCP-соединения с сервером. Приложение исключено из VPN, поэтому замер идёт напрямую. */
object Ping {
    suspend fun tcp(host: String, port: Int, timeoutMs: Int = 3000): Int? = withContext(Dispatchers.IO) {
        runCatching {
            Socket().use { socket ->
                val start = System.nanoTime()
                socket.connect(InetSocketAddress(host, port), timeoutMs)
                ((System.nanoTime() - start) / 1_000_000).toInt()
            }
        }.getOrNull()
    }
}
