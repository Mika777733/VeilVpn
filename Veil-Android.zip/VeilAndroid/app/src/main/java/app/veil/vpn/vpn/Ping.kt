package app.veil.vpn.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Пинг как время TCP-соединения с сервером. Приложение исключено из VPN, поэтому замер идёт напрямую.
 * Одновременно проверяется не больше 4 серверов: в подписке их бывают десятки, и отдельный поток
 * на каждый исчерпывает лимит потоков (OutOfMemoryError: pthread_create).
 */
object Ping {
    @OptIn(ExperimentalCoroutinesApi::class)
    private val dispatcher = Dispatchers.IO.limitedParallelism(4)

    suspend fun tcp(host: String, port: Int, timeoutMs: Int = 2500): Int? = withContext(dispatcher) {
        try {
            Socket().use { socket ->
                val start = System.nanoTime()
                socket.connect(InetSocketAddress(host, port), timeoutMs)
                ((System.nanoTime() - start) / 1_000_000).toInt()
            }
        } catch (e: Exception) {
            null
        }
    }
}
