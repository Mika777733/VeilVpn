package app.veil.vpn.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/** Настройки и ключи — в SharedPreferences, шрифт и иконка — во внутренней папке приложения. */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("veil", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    var servers: List<ServerProfile>
        get() = read("servers") ?: emptyList()
        set(v) = write("servers", v)
    var tunnel: TunnelSettings
        get() = read("tunnel") ?: TunnelSettings()
        set(v) = write("tunnel", v)
    var appearance: AppearanceSettings
        get() = read("appearance") ?: AppearanceSettings()
        set(v) = write("appearance", v)
    var subscriptions: List<String>
        get() = read("subs") ?: emptyList()
        set(v) = write("subs", v)
    var selectedId: String?
        get() = prefs.getString("selected", null)
        set(v) = prefs.edit().putString("selected", v).apply()
    var autoSelect: Boolean
        get() = prefs.getBoolean("auto", false)
        set(v) = prefs.edit().putBoolean("auto", v).apply()

    fun clear() = prefs.edit().clear().apply()

    private inline fun <reified T> read(key: String): T? =
        prefs.getString(key, null)?.let { runCatching { json.decodeFromString<T>(it) }.getOrNull() }

    private inline fun <reified T> write(key: String, value: T) =
        prefs.edit().putString(key, json.encodeToString(value)).apply()
}

object Files {
    fun config(c: Context) = File(c.filesDir, "xray.json")
    fun log(c: Context) = File(c.filesDir, "xray.log")
    fun hasGeo(c: Context) = File(c.filesDir, "geosite.dat").exists()

    private fun fontFile(c: Context) = File(c.filesDir, "custom-font.ttf")
    private fun fontNameFile(c: Context) = File(c.filesDir, "custom-font.name")
    private fun iconFile(c: Context) = File(c.filesDir, "custom-icon.png")

    fun installFont(c: Context, uri: Uri, displayName: String): Boolean {
        val bytes = c.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (bytes.size > 5_000_000) return false
        fontFile(c).writeBytes(bytes)
        return if (loadFont(c) != null) {
            fontNameFile(c).writeText(displayName); true
        } else {
            fontFile(c).delete(); false
        }
    }

    fun loadFont(c: Context): Typeface? =
        fontFile(c).takeIf { it.exists() }?.let { runCatching { Typeface.createFromFile(it) }.getOrNull() }

    fun fontName(c: Context): String? = fontNameFile(c).takeIf { it.exists() }?.readText()

    fun removeFont(c: Context) { fontFile(c).delete(); fontNameFile(c).delete() }

    fun saveIcon(c: Context, uri: Uri): Boolean {
        val src = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return false
        val side = minOf(src.width, src.height)
        val square = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)
        iconFile(c).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return true
    }

    fun loadIcon(c: Context): Bitmap? =
        iconFile(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun removeIcon(c: Context) { iconFile(c).delete() }
}
