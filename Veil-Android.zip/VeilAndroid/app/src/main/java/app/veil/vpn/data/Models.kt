package app.veil.vpn.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class ServerProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val link: String,
    val host: String,
    val port: Int,
    val security: String,
    val sub: String? = null,      // ссылка подписки, из которой пришёл ключ
)

@Serializable
enum class SplitMode(val title: String) {
    ALL("Выкл."), INCLUDE("Только выбранное"), EXCLUDE("Исключения")
}

@Serializable
data class TunnelSettings(
    val dns: String = "1.1.1.1",
    val multihop: Boolean = false,
    val entryId: String? = null,
    val domainMode: SplitMode = SplitMode.ALL,
    val domains: List<String> = emptyList(),
    val appMode: SplitMode = SplitMode.ALL,
    val apps: List<String> = emptyList(),
    val bypassLan: Boolean = true,
    val mux: Boolean = false,
    val fragment: Boolean = false,
    val ipv6: Boolean = false,
)

@Serializable
enum class ThemeMode(val title: String) {
    SYSTEM("Авто"), DARK("Тёмная"), LIGHT("Светлая"), NAVY("Синяя"), AMOLED("AMOLED")
}

@Serializable
enum class IconStyle(val title: String) { TINTED("Цветные"), FILLED("Заливка"), MONO("Моно") }

@Serializable
data class AppearanceSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val accent: Long = 0xFF4A8CFF,
    val iconStyle: IconStyle = IconStyle.TINTED,
    val circleTiles: Boolean = false,
    val font: String = "system",          // system | sans | serif | mono | cursive | custom
    val hasCustomIcon: Boolean = false,
    val iconRev: Int = 0,
)
