module veilcore

go 1.23
