// Package veilcore — ядро Veil для Android: Xray + tun2socks в одной библиотеке.
// Собирается через gomobile в app/libs/veilcore.aar (см. .github/workflows/build.yml).
// В Kotlin доступно как veilcore.Veilcore.startXray(...) и т. д.
package veilcore

import (
	"fmt"
	"os"
	"sync"

	"github.com/xjasonlyu/tun2socks/v2/engine"
	"github.com/xtls/xray-core/core"
	_ "github.com/xtls/xray-core/main/distro/all"
)

var (
	mu       sync.Mutex
	instance *core.Instance
	tunOn    bool
)

// SetAssetDir — папка с geoip.dat и geosite.dat (если они есть).
func SetAssetDir(dir string) {
	os.Setenv("XRAY_LOCATION_ASSET", dir)
}

// StartXray запускает Xray с JSON-конфигом.
func StartXray(configJSON string) error {
	mu.Lock()
	defer mu.Unlock()
	if instance != nil {
		instance.Close()
		instance = nil
	}
	inst, err := core.StartInstance("json", []byte(configJSON))
	if err != nil {
		return err
	}
	instance = inst
	return nil
}

// StartTun направляет пакеты из TUN (fd от VpnService) в SOCKS-вход Xray.
func StartTun(fd int, socksPort int, mtu int) {
	mu.Lock()
	defer mu.Unlock()
	if tunOn {
		engine.Stop()
		tunOn = false
	}
	engine.Insert(&engine.Key{
		Device:   fmt.Sprintf("fd://%d", fd),
		Proxy:    fmt.Sprintf("socks5://127.0.0.1:%d", socksPort),
		MTU:      mtu,
		LogLevel: "warn",
	})
	engine.Start()
	tunOn = true
}

// Stop останавливает туннель и Xray.
func Stop() {
	mu.Lock()
	defer mu.Unlock()
	if tunOn {
		engine.Stop()
		tunOn = false
	}
	if instance != nil {
		instance.Close()
		instance = nil
	}
}

// XrayVersion — версия ядра Xray.
func XrayVersion() string {
	return core.Version()
}
